package mobile.fasam.edu.atividade1;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.SimpleAdapter;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class PedidoActivity extends AppCompatActivity {

    EditText txtNome;
    EditText txtSobrenome;
    EditText txtEmail;
    EditText txtTelefone;
    ListView listView;
    List<HashMap<String,String>> lista = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pedido);
    }

    public void adicionar(View view) {

        txtNome = findViewById(R.id.txtNome);
        txtSobrenome = findViewById(R.id.txtSobrenome);
        txtEmail = findViewById(R.id.txtEmail);
        txtTelefone = findViewById(R.id.txtTelefone);

        //pegar os dados digitados

        String nome, sobrenome, email, telefone;
        nome = txtNome.getText().toString();
        sobrenome = txtSobrenome.getText().toString();
        email = txtEmail.getText().toString();
        telefone = txtTelefone.getText().toString();

        //exibir dados

        String dados = String.format("O texto digitado foi: %s %s %s %s", nome, sobrenome, email, telefone);

        Toast.makeText(getApplicationContext(),dados, Toast.LENGTH_LONG).show();

        //Adiciona dados num mapa de valores (dicionário)
        //Mapa como um "array associativo", K = key, v = value
        HashMap<String,String> map = new HashMap<>();
        map.put("nome",nome);
        map.put("sobrenome",sobrenome);
        map.put("email",email);
        map.put("telefone",telefone);

        lista.add(map);

        //Mapeamento de dados do List<HashMap<K,V> para
        //imprimir no layout
        String[] de = {"nome","sobrenome", "email", "telefone"}; //dados do Map

        //id's do layout item.xml
        int[] para = {R.id.labelNome,R.id.labelSobrenome,R.id.labelEmail,R.id.labelTelefone};

        //Criar o simpleAdapter
        SimpleAdapter adapter = new SimpleAdapter(
                getApplicationContext(),
                lista,
                R.layout.item,
                de,
                para
        );

        //Buscar a listView e imprimir os dados
         listView = findViewById(R.id.listView);
        listView.setAdapter(adapter);


    }


    }

